# Unicity Paid Service Agent

In project yek `paid service agent` darim ke ba DM kar mikonad:

- user service mikhad
- agent quote misazad
- user quote ra accept mikonad
- agent `payment request` رسمی Unicity mifrestad
- ba'd az `paid`, agent natije ra az tariq DM barmigardanad

In flow baraye Builder Program monaseb ast, چون هم `agentic` ast, هم payment dar khodesh darad, هم baraye demo kardan vazeh ast.

## Services

- `summarize`
- `rewrite`
- `keywords`
- `title`

## DM Commands

- `catalog`
- `help`
- `balance`
- `jobs`
- `quote summarize | your text here`
- `quote rewrite | your text here`
- `quote keywords | your text here`
- `quote title | your text here`
- `accept <jobId>`
- `status <jobId>`

## Setup

```bash
npm install
copy .env.example .env
npm run dev
```

Current local agent nametag:

- `@uncutiyagent260701`

## Env

- `SPHERE_NAMETAG` optional ast ta agent ba yek nametag mashkhas bala biyad
- `AUTHORIZED_SENDERS` agar khali bماند agent open mimanad
- `SERVICE_COIN_ID` coin pishfarz service ast
- `QUOTE_EXPIRY_MINUTES` omr-e quote ra moshakhas mikonad

## Architecture

- `src/index.ts`: orchestration, DM command handling, payment-request flow
- `src/jobStore.ts`: zakhire-ye paydar baraye quote/job ha
- `src/services.ts`: service logic va pricing

## Why this is stronger than a basic treasury bot

- user-facing story vazeh tar dare
- پرداخت be طور mostaghim jozv az flow ast
- baraye live demo jaleb tar ast
- rahat tar mishavad ba LLM, invoice, ya swap gosteresh dad

## References

- Sphere SDK: <https://github.com/unicity-sphere/sphere-sdk>
- Sphere CLI: <https://github.com/unicity-sphere/sphere-cli>
