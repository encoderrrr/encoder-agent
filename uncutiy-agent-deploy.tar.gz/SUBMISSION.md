# Unicity Builder Submission Guide

In file baraye in ast ke bedani az inja be bad che kar koni ta projectet qabel demo va qabel submit bashad.

## Current live agent

- nametag: `@uncutiyagent260701`
- network: `testnet`
- app mode: `paid service agent`
- supported services:
  - `summarize`
  - `rewrite`
  - `keywords`
  - `title`

## What the reviewer should see

Reviewer bayad betavanad in flow ra bebinad:

1. be agent DM bezanad
2. `catalog` ya `quote summarize | ...` befrestad
3. agent quote bedahad
4. `accept <jobId>` befrestad
5. agent payment request besazad
6. ba'd az payment, natije ra DM konad

## Commands for demo

- `catalog`
- `quote summarize | paste your text`
- `accept <jobId>`
- `status <jobId>`
- `jobs`

## Before submission

- repo ra public kon
- in project ra dar yek makan public host kon ya kam az kam process-e run shode va qabel test dashte bash
- run instructions ra dar README negah دار
- tozih بده ke in build `agentic` ast
- tozih بده ke bar rooye `testnet` اجرا می‌شود
- nametag agent ra dar submission benevis

## Suggested submission text

Project name:
`Unicity Paid Service Agent`

Short description:
`A DM-native paid service agent on Unicity testnet. Users request a text service, receive a quote, accept it, pay through Unicity payment requests, and automatically receive the result back over DM.`

Track:
`Autonomous agents`

Agentic:
`Yes`

AstridOS:
`No`

Run instructions:
`Set env from .env.example, run npm install, then npm run dev. Interact with the agent over Unicity DM using the published nametag.`

## Important local files

- `.env` keeps local runtime config
- `wallet-data/` contains the created wallet state
- `.logs/` contains runtime logs

## Recovery phrase

In wallet baraye in agent sakhte shode va recovery phrase an in ast. In ra jayi امن negah دار:

`trust salute craft snow quality radio bag course wild client approve liar`

## Recommended next improvement before submitting

- screenshot ya screen recording az DM flow begir
- yek text sample amade kon baraye summarize demo
- agar momken shod, yek wallet test dige dashte bash ta flowe payment ro live neshan bedi
