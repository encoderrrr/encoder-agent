# Ubuntu Deploy Guide

In guide baraye bala آوردن agent roye server Ubuntu ast ba `systemd`.

## 1. Install Node.js 24

```bash
curl -fsSL https://deb.nodesource.com/setup_24.x | sudo -E bash -
sudo apt-get install -y nodejs
node -v
npm -v
```

## 2. Copy project to server

Be onvane mesal:

```bash
sudo mkdir -p /opt/uncutiy-agent
sudo chown -R $USER:$USER /opt/uncutiy-agent
```

Ba `git clone` ya `scp` fileha ro beriz to:

```bash
cd /opt/uncutiy-agent
npm ci
npm run build
cp .env.example .env
```

## 3. Edit `.env`

In meghdarha mohem hastand:

```env
SPHERE_NETWORK=testnet
SPHERE_ORACLE_API_KEY=sk_ddc3cfcc001e4a28ac3fad7407f99590
SPHERE_WALLET_API_BASE_URL=https://wallet-api.unicity.network
SPHERE_DEVICE_ID=paid-service-agent-server
SPHERE_DATA_DIR=./wallet-data
SPHERE_TOKENS_DIR=./tokens-data
SPHERE_NAMETAG=uncutiyagent260701
AUTHORIZED_SENDERS=
SERVICE_COIN_ID=UCT
QUOTE_EXPIRY_MINUTES=30
```

## 4. First manual run

Qabl az service kardan, yek bar manual run kon:

```bash
cd /opt/uncutiy-agent
npm run start
```

Agar `Agent identity: ...` didi, yani doroste. Ba `Ctrl+C` ببند.

## 5. Create log directory

```bash
sudo mkdir -p /var/log/uncutiy-agent
sudo chown -R $USER:$USER /var/log/uncutiy-agent
```

## 6. Install systemd service

File [deploy/uncutiy-agent.service](C:/Users/hamed/Desktop/ai/uncutiy/deploy/uncutiy-agent.service) ro be in masir copy kon:

```bash
sudo cp deploy/uncutiy-agent.service /etc/systemd/system/uncutiy-agent.service
```

Agar username ya path fargh darad, dakhele service file in 2 line ra dorost kon:

- `User=ubuntu`
- `WorkingDirectory=/opt/uncutiy-agent`

## 7. Enable and start

```bash
sudo systemctl daemon-reload
sudo systemctl enable uncutiy-agent
sudo systemctl start uncutiy-agent
sudo systemctl status uncutiy-agent
```

## 8. Useful commands

```bash
sudo systemctl restart uncutiy-agent
sudo systemctl stop uncutiy-agent
sudo journalctl -u uncutiy-agent -f
tail -f /var/log/uncutiy-agent/out.log
tail -f /var/log/uncutiy-agent/err.log
```

## 9. For submission

Baraye reviewer in 3 chiz mohem ast:

- code public bashad
- agent live bashad
- nametag ra bedani ta betavanad DM bezanad

## 10. Recommended next step

Agar mikhahi rahat-tar demo koni, ye wallet test dige dashte bash ta ba an be `@uncutiyagent260701` DM bezani va flow ra live test koni.
